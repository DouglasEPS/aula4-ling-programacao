#include <stdio.h>

void imprimir_string(char *str) {
    while(*str != '\0') {
        printf("%c", *str);
        str++;
    }
    printf("\n");
}

int contar_caracteres(char *str) {
    int contador = 0;
    while(*str != '\0') {
        contador++;
        str++;
    }
    return contador;
}

void inverter_string(char *str) {
    char *inicio = str;  // ponteiro no início
    char *fim = str;

    // move o ponteiro 'fim' até o último caractere
    while (*fim != '\0') {
        fim++;
    }
    fim--;  // recua para o último caractere válido

    // troca os caracteres enquanto inicio < fim
    while (inicio < fim) {
        char temp = *inicio;
        *inicio = *fim;
        *fim = temp;

        inicio++;
        fim--;
    }
}

int main() {
    char palavra[100]; // espaço para a palavra

    printf("Escreva a palavra que deseja fazer a operacao: ");
    scanf("%s", palavra); // já é endereço do primeiro elemento

    printf("String original: %s\n", palavra);
    printf("Usando ponteiro: ");
    imprimir_string(palavra);

    printf("Número de caracteres: %d\n", contar_caracteres(palavra));

    inverter_string(palavra); // chama a função 
    printf("Palavra invertida: %s\n", palavra);

    return 0;
}
