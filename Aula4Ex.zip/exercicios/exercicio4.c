#include <stdio.h>

// Função para calcular estatísticas de um array de notas
void calcular_estatisticas(float *notas, int quantidade,
float *media, float *maior, float *menor) {

    float soma = 0.0;        // soma das notas
    float *p = notas;        // ponteiro vetor

    // parâmetros de comparação
    *maior = *notas;
    *menor = *notas;

    // percorre o vetor
    for (p = notas; p < notas + quantidade; p++) {
        soma += *p;              // soma a nota atual

        if (*p > *maior) {
            *maior = *p;         // atualiza maior
        }
        if (*p < *menor) {
            *menor = *p;         // atualiza menor
        }
    }

    // calcula a média
    *media = soma / quantidade;
}

int main() {

    int qtd_notas;

    printf("Digite a quantidade de notas: ");
    scanf("%d", &qtd_notas);

    float notas[qtd_notas];

    printf("\nDigite as notas: \n");
    for(int i = 0; i < qtd_notas; i++){
        scanf("%f", &notas[i]);
    }

    float media, maior, menor;

    calcular_estatisticas(notas, qtd_notas, &media, &maior, &menor);

    printf("Média: %.2f\n", media);
    printf("Maior nota: %.2f\n", maior);
    printf("Menor nota: %.2f\n", menor);

    return 0;
}
