#include <stdio.h>

// Função que encontra o maior elemento usando ponteiros
int encontrar_maior(int *array, int tamanho) {
    int *maior = array; // ponteiro para o primeiro elemento

    // percorre o vetor usando ponteiros
    for (int *p = array; p < array + tamanho; p++) {
        if (*p > *maior) {
            maior = p; // atualiza o ponteiro "maior"
        }
    }

    return *maior; // retorna o valor armazenado no endereço
}

int main() {
    int tamanho;

    printf("Digite o tamanho do vetor: ");
    scanf("%d", &tamanho);

    int numeros[tamanho];

    printf("Digite os elementos do vetor:\n");
    for (int i = 0; i < tamanho; i++) {
        scanf("%d", (numeros + i)); // usando ponteiros em vez de []
    }

    int maior = encontrar_maior(numeros, tamanho);

    printf("Array: ");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", *(numeros + i)); // acessando por ponteiro
    }

    printf("\nMaior elemento: %d\n", maior);

    return 0;
}
